Rails.application.routes.draw do
  root :to => "hotels#index"
  resources :hotels
  post "/requested_bookings" => "hotels#requested_bookings"
  get "/hotels/:hotel_id/:room_type/availability" => "hotels#check_availability"
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
