class Hotel < ApplicationRecord
	has_many :requested_bookings

	def blocked_dates(room_type = nil)
		dates = []
		if room_type.blank?
			requested_bookings.where("move_in_date >= ?", Date.today).each do |rb|
				dates << (rb.move_in_date..rb.move_out_date).to_a
			end
		else
			requested_bookings.where("move_in_date >= ? and room_type =?", Date.today, room_type).each do |rb|
				dates << (rb.move_in_date..rb.move_out_date).to_a
			end
		end
		return dates.flatten.collect{|v| v.strftime('%d %b %Y')}
	end

	def next_available_date
		if is_available
			( (Date.today..15.days.from_now).to_a - blocked_dates).first&.strftime('%d %b %Y')
		else
			"Not available."
		end
	end
end
