class RequestedBooking < ApplicationRecord
	belongs_to :hotel
	validates :hotel_id, :move_in_date, :move_out_date, presence: true

	#######
	ROOM_TYPES = ["Single", "Double", "Mini-Suite", "Master Suite", "Studio", "Double-double", "Twin", "Queen"]
end
