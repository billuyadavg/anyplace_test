module HotelsHelper
end
