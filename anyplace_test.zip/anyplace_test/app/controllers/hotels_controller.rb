class HotelsController < ApplicationController
  before_action :set_hotel, only: [:show, :edit, :update, :destroy]

  # GET /hotels
  # GET /hotels.json
  def index
    @hotels = Hotel.all
  end

  # GET /hotels/1
  # GET /hotels/1.json
  def show
  end

  # GET /hotels/new
  def new
    @hotel = Hotel.new
  end

  # GET /hotels/1/edit
  def edit
  end

  # POST /hotels
  # POST /hotels.json
  def create
    @hotel = Hotel.new(hotel_params)

    respond_to do |format|
      if @hotel.save
        format.html { redirect_to @hotel, notice: 'Hotel was successfully created.' }
        format.json { render :show, status: :created, location: @hotel }
      else
        format.html { render :new }
        format.json { render json: @hotel.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /hotels/1
  # PATCH/PUT /hotels/1.json
  def update
    respond_to do |format|
      if @hotel.update(hotel_params)
        format.html { redirect_to @hotel, notice: 'Hotel was successfully updated.' }
        format.json { render :show, status: :ok, location: @hotel }
      else
        format.html { render :edit }
        format.json { render json: @hotel.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /hotels/1
  # DELETE /hotels/1.json
  def destroy
    @hotel.destroy
    respond_to do |format|
      format.html { redirect_to hotels_url, notice: 'Hotel was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  def check_availability
    @hotel = Hotel.find(params[:hotel_id])
    blocked_dates = @hotel.blocked_dates(params[:room_type])
    is_available = !(blocked_dates.include?(params[:move_in_date].to_date&.strftime('%d %b %Y')) )
    respond_to do |format|
      format.json { render json: {is_available: is_available}, status: :success }
    end
  end

  def requested_bookings
    rb = RequestedBooking.new(requested_booking_params)

    respond_to do |format|
      if rb.save
        @hotel = rb.hotel
        format.html { redirect_to hotels_url, notice: 'Hotel room booked successfully.' }
        format.json { render :show, status: :ok, location: @hotel }
      else
        format.html { redirect_to hotels_url, notice: 'Unable to book the room.' }
        format.json { render json: rb.errors, status: :unprocessable_entity }
      end
    end

  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_hotel
      @hotel = Hotel.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def hotel_params
      params.require(:hotel).permit(:name, :is_available, :cover_image_url)
    end

    def requested_booking_params
      params.require(:requested_booking).permit(:hotel_id, :room_type, :move_in_date, :move_out_date)
    end
end
