require 'test_helper'

class RequestedBookingTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
