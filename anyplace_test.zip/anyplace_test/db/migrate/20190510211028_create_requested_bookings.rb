class CreateRequestedBookings < ActiveRecord::Migration[5.2]
  def change
    create_table :requested_bookings do |t|
      t.integer :hotel_id
      t.string :room_type
      t.date :move_in_date
      t.date :move_out_date
      t.integer :rate

      t.timestamps
    end
  end
end
